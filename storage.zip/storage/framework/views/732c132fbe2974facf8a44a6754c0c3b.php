<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Website Tes Talenta Indonesia Raya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
      <section>
          <div class="container">
              <div class="row">
                <div class="col-md-12">
                <h1 class="text-center">Website Tes Talenta Indonesia Raya</h1>
                <h2 class="text-center">Data Users</h2>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/dashboard">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Data Users</li>
                  </ol>
                </nav>
                <table class="table table-responsive">
                    <thead>
                      <tr>
                        <th scope="col">No</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Usia</th>
                      </tr>
                    </thead>
                    <tbody class="table-group-divider">
                      <tr>
                        <th scope="row">1</th>
                        <td>Unggar Madi</td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>Jacob</td>
                        <td>Thornton</td>
                        <td>@fat</td>
                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td colspan="2"></td>
                        <td>@twitter</td>
                      </tr>
                    </tbody>
                  </table>
                  <div>
                    <canvas id="myChart" class="mt-5"></canvas>
                    <button class="mt-5 btn btn-primary position-absolute top-150 start-50 translate-middle">Cetak PDF</button>
                  </div>
                </div>
            </div>
        </div>
    </section>
    <canvas id="line-chart" width="800" height="450"></canvas>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const ctx = document.getElementById('myChart');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['L U19', 'P U19', 'L U20', 'P U20'],
      datasets: [{
        label: 'Persentase',
        data: [30, 17, 3, 5, 2, 3],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
</body>
</html>

<?php /**PATH C:\laragon\www\Website-Tes-Talenta-Indo-Raya\resources\views/users.blade.php ENDPATH**/ ?>