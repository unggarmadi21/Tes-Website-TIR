<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('dashboard');
});
Route::get('/users', function () {
    return view('users');
});

// Route::prefix('dashboard')->namespace('Dashboard')->group(function(){
//     Route::get('dashboard', 'DashboardController@index')->name('dashboard');
//     Route::resource('users','UsersController');
// });

// Route::get('dashboard', [App\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');
// Route::get('users', [App\Http\Controllers\UsersController::class, 'index'])->name('users');



