<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Website Tes Talenta Indonesia Raya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
      <div class="row">
    <h1 class="mt-3 mb-3 text-center">Dashboard Website Tes Talenta Indonesia Raya</h1>
    <div class="col-md-8">
      <form action="">
        <h2>Masukan Nama</h2>
        <div class="input-group mb-3 mt-3">
          <span class="input-group-text" name="name" id="basic-addon1">Nama</span>
          <input type="text" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>
        <h2>Jenis Kelamin</h2>
        <div class="form-check">
          <input class="form-check-input" type="radio"  name="jenis_kelamin"  id="flexRadioDefault1">
          <label class="form-check-label" for="flexRadioDefault1">
           Laki - laki
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="jenis_kelamin" id="flexRadioDefault2" checked>
          <label class="form-check-label" for="flexRadioDefault2">
           Perempuan
          </label>
        </div>
        <h2>Masukan Usia</h2>
        <div class="input-group mb-3 mt-3">
          <span class="input-group-text" id="basic-addon1">Usia</span>
          <input type="number" name="usia" class="form-control" aria-label="Username" aria-describedby="basic-addon1">
        </div>
        <button type="submit" class="mt-3 btn btn-primary"><a class="text-success" href="/users">Submit</a></button>
      </form>
  </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  </body>
</html>